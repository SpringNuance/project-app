The project application can be launched at this address:
https://project-app-springnuance.herokuapp.com/